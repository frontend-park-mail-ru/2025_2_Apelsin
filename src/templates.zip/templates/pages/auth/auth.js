import template from './auth.hbs';


export class auth {
    #parent;

    /**
     * Конструктор класса
     * @param parent {HTMLElement} - родительский элемент
     */
    constructor(parent, type) {
        this.#parent = parent;
    }

    get self() {
        return document.auth
    }


    nextCallback() {
        console.log("NEXT")
    }

    prevCallback() {
        console.log("PREV")
    }

    /**
     * Очистка
     */
    remove() {
        this.self.remove();
    }

    /**
     * Рендеринг формы
     */
    render() {
        console.log("register form render");

        this.#parent.insertAdjacentHTML(
            "beforeend",
            template()
        );
    }
}