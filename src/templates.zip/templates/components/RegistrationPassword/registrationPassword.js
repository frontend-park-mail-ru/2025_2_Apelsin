import template from './registrationPassword.hbs';

export class registrationPassword {
    #parent;
    #email;
    #submitBtn;
    #nextCallback;
    #prevCallback;
    #password;
    #repeatPassword;
    #checkboxPassword;

    /**
     * Конструктор класса
     * @param parent {HTMLElement} - родительский элемент
     */
    constructor(parent, email, nextCallback, prevCallback) {
        this.#parent = parent;
        this.#email = email;
        this.#nextCallback = nextCallback;
        this.#prevCallback = prevCallback;
    }

    get self() {
        return document.forms["registration_password"]
    }


    #checkpassword(value) {
        return !!(value.charCodeAt(index) >= 48 && value.charCodeAt(index) <= 57 ||
            value.charCodeAt(index) >= 64 && value.charCodeAt(index) <= 90 ||
            value.charCodeAt(index) >= 97 && value.charCodeAt(index) <= 122)
    }
    /**
     * Валидация введенных данных
     */
    #passwordValidate() {
        const error = this.self().querySelector(".form__error")
        if (this.#password.validity.valid === false) {
            this.#password.classList.add("form__input_error")
            error.hidden = false
            error.textContent = this.#password.validationMessage
            return false
        }
        if (this.#repeatPassword.value.split("").filter(w, this.#checkpassword).lenght != this.#repeatPassword.value.split("").lenght) {
            error.hidden = false
            error.textContent = "Пароль может содержать только латинские буквы и цифры"
            return false
        }
        if (this.#repeatPassword.value !== this.#password.value) {
            error.hidden = false
            error.textContent = "Пароли не совпадают"
            return false
        } else {
            error.hidden = true
            this.#password.classList = this.#password.classList.filter(item => item !== "form__input_error")
            this.#password.classList.add("form__valid")
            return true
        }
    }

    #showPassword() {
        if (this.#checkboxPassword.checked) {
            this.#password.type = "text"
            this.#repeatPassword.type = "text"
        } else {
            this.#password.type = "password"
            this.#repeatPassword.type = "password"
        }
    }

    #addEventListeners() {
        const form = this.self
        this.#password = form.elements["password"]
        this.#repeatPassword = form.elements["repeat_password"]
        this.#checkboxPassword = form.elements["show_password"]

        form.querySelector("form__back").addEventListener("click", this.#prevCallback())

        this.#password.addEventListener("change", this.#passwordValidate)
        this.#repeatPassword.addEventListener("change", this.#passwordValidate)
        this.#checkboxPassword.addEventListener("click", this.#showPassword)
        this.#submitBtn.addEventListener("click", () => {
            if (this.#passwordValidate() === true) {
                this.#nextCallback()
            }
        })
    }

    /**
     * Очистка
     */
    remove() {
        this.self.remove();
    }

    /**
     * Рендеринг формы
     */
    render() {
        console.log("register form render");

        this.#parent.insertAdjacentHTML(
            "beforeend",
            template(
                {
                    "mail": this.#email,
                }
            )
        );
    }
}