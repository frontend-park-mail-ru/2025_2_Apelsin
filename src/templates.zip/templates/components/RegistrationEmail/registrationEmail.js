import template from './registrationEmail.hbs';

export class registrationEmail {
    #parent;
    #type;
    #email;
    #submitBtn;
    #nextCallback;
    #prevCallback;

    /**
     * Конструктор класса
     * @param parent {HTMLElement} - родительский элемент
     */
    constructor(parent, type, nextCallback, prevCallback) {
        this.#parent = parent;
        this.#type = type;
        this.#nextCallback = nextCallback;
        this.#prevCallback = prevCallback;
    }

    get self() {
        return document.forms["registration_email"]
    }

    getType() {
        return this.#type
    }

    getEmail() {
        return this.#email
    }

    hide() {
        this.self().hidden = true
    }

    show() {
        this.self().hidden = false
    }

    #switch() {
        this.#type = this.#type === "company" ? "user" : "company"
        this.#under_link();
    }

    #under_link() {
        if (this.#type === "company") {
            document.i_need_users.hidden = false
            document.i_need_job.hidden = true
        } else {
            document.i_need_users.hidden = true
            document.i_need_job.hidden = false
        }
    }

    /**
     * Валидация введенных данных
     */
    #emailValidate() {
        const error = this.self().querySelector(".form__error")
        if (this.#email.validity.valid === false) {
            error.hidden = false
            error.textContent = this.#email.validationMessage
            return false
        } else {
            error.hidden = true
            this.#email.classList.add("form__valid")
            return true
        }
    }

    #addEventListeners() {
        const form = this.self
        this.#email = form.elements["email"]
        this.#submitBtn = form.elements["submit"]

        form.querySelector("form__back").addEventListener("click", this.#prevCallback())
        form.querySelectorAll("under_link").forEach(element => {
            element.addEventListener("click", this.#switch);
        })

        this.#email.addEventListener("change", this.#emailValidate)
        this.#submitBtn.addEventListener("click", () => {
            if (this.emailValidate === true) {
                this.#nextCallback()
            }
        })
    }

    /**
     * Очистка
     */
    remove() {
        this.self.remove();
        document.querySelectorAll("under_link").forEach(element, () => {
            element.remove();
        })
    }

    /**
     * Рендеринг формы
     */
    render() {
        console.log("register form render");

        this.#parent.insertAdjacentHTML(
            "beforeend",
            template(
                {
                    "type" : this.#type,
                }
            )
        );
        this.#under_link();
        this.#addEventListeners();
    }
}